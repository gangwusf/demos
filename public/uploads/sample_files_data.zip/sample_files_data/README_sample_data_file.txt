The data file can be either one of CSV or JSON formats.


######### CSV format #########

For CSV format, the first row (row index 0) is the list of variables names (comma separated), and the rest of the rows contain the rows of the data array. For time series data, row index 1 corresponds to the oldest time and the last row index corresponds to the latest time in the time series.

Alternatively, here is a Python code snippet that will save your numpy data array (data_array) and a Python list of variable names (var_names) to a CSV file that is readable by our UI.

import pandas as pd
data_array = np.random.randn(1000,4) # Replace this with your actual data array
var_names = ['a', 'b', 'c', 'd'] # Note the number of variable names (4) is the same as the size of the 1st dimension of data_array (also 4)

file_path='path/to/file'
df = pd.DataFrame(data_array, columns=var_names)
df.to_csv(f"{file_path}", index = False)



######### JSON format ########


For JSON format, here is a Python code snippet that will save your numpy data array (data_array) and a Python list of variable names (var_names) to a JSON file that is readable by our UI.

import json
data_array = np.random.randn(1000,4) # Replace this with your actual data array
var_names = ['a', 'b', 'c', 'd'] # Note the number of variable names (4) is the same as the size of the 1st dimension of data_array (also 4)

file_path='path/to/file'
data_array_to_list = data_array.tolist()
data_json = {'data': data_array_to_list, 'varNames': var_names}
with open(f"{file_path}", "w") as fp:
    json.dump(data_json, fp)